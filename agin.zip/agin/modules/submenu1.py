from agin import *

@bot.on(events.CallbackQuery(data=b'submenu1'))
async def submenu1(event):
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	if sender.id in a:
		z = await event.edit(buttons=[
[Button.inline(" Panel SSH Menu ","ssh-menu")],
[Button.inline(" Panel Vmess Menu ","vmess-menu"),
Button.inline(" Panel Vless Menu ","vless-menu")],
[Button.inline(" Panel Trojan-ws Menu ","trwsmenu")],
[Button.inline(" Panel Shadownsocks  Menu ","shadowsocks"),
Button.inline(" Panel Trojan-GFW Menu ","trgfwmenu")],
[Button.inline(" 🔙 Back To Menu","menu")]])
		if not z:
			await event.respond(buttons=[
[Button.inline(" Panel SSH Menu ","ssh-menu")],
[Button.inline(" Panel Vmess Menu ","vmess-menu"),
Button.inline(" Panel Vless Menu ","vless-menu")],
[Button.inline(" Panel Trojan-ws Menu ","trwsmenu")],
[Button.inline(" Panel Shadownsocks  Menu ","shadowsocks"),
Button.inline(" Panel Trojan-GFW Menu ","trgfwmenu")],
[Button.inline(" 🔙 Back To Menu","menu")]])

	else:
		val = valid(sender.id)
		if val == "false":
			try:
				await event.answer("**Akses ditolak ❌**")
			except:
				await event.respond("**Akses Ditolak ❌**")
		else:
			x = await event.edit(buttons=[
[Button.inline(" Panel SSH Menu ","ssh-menu")],
[Button.inline(" Panel Vmess Menu ","vmess-menu"),
Button.inline(" Panel Vless Menu ","vless-menu")],
[Button.inline(" Panel Trojan-ws Menu ","trwsmenu")],
[Button.inline(" Panel Shadownsocks  Menu ","shadowsocks"),
Button.inline(" Panel Trojan-GFW Menu ","trgfwmenu")],
[Button.inline(" 🔙 Back To Menu","menu")]])
			if not x:
				await event.respond(buttons=[
[Button.inline(" Panel SSH Menu ","ssh-menu")],
[Button.inline(" Panel Vmess Menu ","vmess-menu"),
Button.inline(" Panel Vless Menu ","vless-menu")],
[Button.inline(" Panel Trojan-ws Menu ","trwsmenu")],
[Button.inline(" Panel Shadownsocks  Menu ","shadowsocks"),
Button.inline(" Panel Trojan-GFW Menu ","trgfwmenu")],
[Button.inline(" 🔙 Back To Menu","menu")]])
