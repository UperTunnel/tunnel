from agin import *

@bot.on(events.CallbackQuery(data=b'addvless'))
async def vless(event):
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		async with bot.conversation(event.chat_id) as buttonname:
			await event.respond("**Nama Server  `Ex: 🇸🇬 SG DigitalOcean` **")
			buttonname = buttonname.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			buttonname = await buttonname
			buttonname = buttonname.message.message
		async with bot.conversation(event.chat_id) as harga7:
			await event.respond("**Harga 7 Day:**")
			harga7 = harga7.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			harga7 = await harga7
			harga7 = harga7.message.message
		async with bot.conversation(event.chat_id) as harga:
			await event.respond("**Harga 30 Day:**")
			harga = harga.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			harga = await harga
			harga = harga.message.message
		async with bot.conversation(event.chat_id) as domain:
			await event.respond("**Domain: **")
			domain = domain.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			domain = await domain
			domain = domain.message.message
		async with bot.conversation(event.chat_id) as quota:
			await event.respond("**Quota: **")
			quota = quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			quota = await quota
			quota = quota.message.message
		async with bot.conversation(event.chat_id) as limitip:
			await event.respond("**Limit IP: **")
			limitip = limitip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limitip = await limitip
			limitip = limitip.message.message
		async with bot.conversation(event.chat_id) as limcounted:
			await event.respond("**Max Create Account: **")
			limcounted = limcounted.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limcounted = await limcounted
			limcounted = limcounted.message.message
		async with bot.conversation(event.chat_id) as pubkey:
			await event.respond("**Pub Key Slow Keong: **")
			pubkey = pubkey.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pubkey = await pubkey
			pubkey = pubkey.message.message
		z = db.execute("INSERT INTO vless (buttonname,harga7,harga,domain,quota,limitip,limcounted,pubkey) VALUES (?,?,?,?,?,?,?,?)",
		(buttonname,harga7,harga,domain,quota,limitip,limcounted,pubkey))
		db.commit()
		msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ Add Server VLESS Success ⟩**
**━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 Domain Name:** `{domain}`
**🔰 harga 7 Day:** `{harga7}`
**🔰 harga 30 Day:** `{harga}`
**🔰 Quota:** `{quota}`
**🔰 Limit IP:** `{limitip}`
**🔰 Limit Create Account:** `{limcounted}`
**━━━━━━━━━━━━━━━━**
"""
		await event.respond(msg)
