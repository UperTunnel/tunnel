from agin import *

@bot.on(events.CallbackQuery(data=b'delmem'))
async def delmem(event):
	async def delmem_(event):
		z = db.execute("SELECT email FROM user").fetchall()
		do = []
		for al in z:
			do.append([Button.inline(al[0])])
		await event.edit("**Choose User**",
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			email = await conv
			email = email.data.decode("ascii")
		saldo = db.execute("SELECT saldo FROM user WHERE email = (?)",(email,)).fetchone()[0]
		member = db.execute("SELECT member FROM user WHERE email = (?)",(email,)).fetchone()[0]
		xs = await bot.get_entity(int(member))
		msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ Informasi Reseller ⟩**
**━━━━━━━━━━━━━━━━**
**» Nama:** `{xs.first_name}`
**» Username:** `{xs.username}`
**» Member ID:** `{member}`
**» Saldo Tersisa:** `{saldo}`
**» Email:** `{email}`
**━━━━━━━━━━━━━━━━**
**⟨ Yakin Ingin Menghapus Reseller? ⟩**
**━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=[
[Button.inline("Ya","y"),Button.inline("Tidak","n")],
[Button.inline("«« Back To Menu ««","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") == "y":
			db.execute("DELETE FROM user WHERE email = (?)",
			(email,))
			db.commit()
			await event.respond("**Berhasil menghapus reseller**")
		elif con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")

	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	sender = await event.get_sender()
	if sender.id in a:
		await delmem_(event)
	else:
		await event.answer("Akses Ditolak!")