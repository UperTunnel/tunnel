from agin import *

@bot.on(events.CallbackQuery(data=b'rentrgfwo'))
async def rentrgfw(event):
		async def rentrgfw_(event):
			z = db.execute("SELECT buttonname FROM trojangfw").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
					conv = conv.wait_event(events.CallbackQuery)
					buttonname = await conv
					buttonname = buttonname.data.decode("utf-8")
					harga = db.execute("SELECT harga FROM trojangfw WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					domain = db.execute("SELECT domain FROM trojangfw WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
					
					r = requests.get("http://"+domain+":6969/cektr").text
					all_ = r.split("\n")
					all_list = []
					for x in all_:
						all_list.append("`"+x+"`")
						y = "\n".join(all_list)
						msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**  USER LIST TROJAN  **
**━━━━━━━━━━━━━━━━━━━**
{y}
**Choose User Number**
"""
					await event.respond(msg)
			async with bot.conversation(event.chat_id) as num:
					await event.edit()
					num = num.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					num = await num
					num = num.message.message
			async with bot.conversation(event.chat_id) as user:
					await event.reply("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
#[Button.inline("30 Day","30")],
#[Button.inline("60 Day","60")],
[Button.inline("30 Day","30")]])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
			if int(val["saldo"]) < harga:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				if exp == "30":
					min = harga
				if exp == "60":
					min = harga*2
				if exp == "90":
					min = harga*3
				param = f":6969/rentr?num={num}&exp={exp}"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						count = db.execute("SELECT counted FROM trojangfw WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE trojangfw SET counted = (?) WHERE domain = (?)",
						(int(count)+int(0),domain,))
						db.commit()
					except:
						pass
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					print(r)
					msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**  Successfully Renewed **
**━━━━━━━━━━━━━━━━━━━**

**» Client Name:** `{user}`
**» Expired Until:** `{later}`

**━━━━━━━━━━━━━━━━━━━**
**━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
					dat = {
				"email":val["email"],
                                "protocol":"Renew Trojan-ws",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		data = event.data.decode("ascii").split("-")[0]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				val = {"saldo":"100000000"}
				await rentrgfw_(event)
		else:
			await rentrgfw_(event)
			
@bot.on(events.CallbackQuery(data=b'trojangfw-trial'))
async def trojangfwtrial(event):
		async def trojangfwtrial_(event):
			z = db.execute("SELECT buttonname FROM trojangfw").fetchall()
			do = []
			for i,k in zip(z[0::2], z[1::2]):
				print(i)
				print(k)
				do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
			if ( len(z) % 2 ) == True:
				do.append([Button.inline(z[-1][0])] )
			await event.edit(
buttons=do)
			async with bot.conversation(event.chat_id) as conv:
				conv = conv.wait_event(events.CallbackQuery)
				buttonname = await conv
				buttonname = buttonname.data.decode("utf-8")
				domain = db.execute("SELECT domain FROM trojangfw WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
				param = f":6969/trial-trojan"
				r = requests.get("http://"+domain+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(0),sender.id,))
						count = db.execute("SELECT counted FROM trojangfw WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE trojangfw SET counted = (?) WHERE domain = (?)",
						(int(count)+int(0),domain,))
						db.commit()
					except:
						pass
					print(r.text)
					x = r.text
					today = DT.date.today()
					later = today + DT.timedelta(days=int(1))
					print(x)
					domain = re.search("@(.*?):",x).group(1)
					port = re.search(domain+":(.*)",x).group(1)
					uuid = re.search("trojan://(.*?)@",x).group(1)
					try:
						remarks = re.search("#(.*)",x).group(1)
					except:
						remarks = uuid
					msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**  TRIAL Trojan-GFW  **
**━━━━━━━━━━━━━━━━━━━**
**»Remarks:** `{uuid}`
**» Domain:** `{domain}`
**» Port TLS:** `443`
**» UUID:** `{uuid}`
**━━━━━━━━━━━━━━━━━━━**
**,»TROJAN-GFW Url:**
  `{x.replace(" ","").strip()}`
**━━━━━━━━━━━━━━━━━━━**
**📆 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
		sender = await event.get_sender()
		val = valid(sender.id)
		db = get_db()
		x = db.execute("SELECT * FROM admin").fetchall()
		a = [v[0] for v in x]
		if val == "false":
			if sender.id not in a:
				await event.answer("Akses Ditolak")
			else:
				await trojangfwtrial_(event)
		else:
			if str(val["saldo"]) == "0":
				await event.respond('**Saldo Kamu Kosong**')
			else:
				await trojangfwtrial_(event)
				
@bot.on(events.CallbackQuery(data=b'create-trojangfw'))
async def trojangfw(event):
	async def trojangfw_(event):
		z = db.execute("SELECT buttonname FROM trojangfw").fetchall()
		do = []
		for i,k in zip(z[0::2], z[1::2]):
			print(i)
			print(k)
			do.append([Button.inline(i[0]),
                                   Button.inline(k[0])])
		if ( len(z) % 2 ) == True:
			do.append([Button.inline(z[-1][0])] )
		await event.edit(
buttons=do)
		async with bot.conversation(event.chat_id) as conv:
			conv = conv.wait_event(events.CallbackQuery)
			buttonname = await conv
			buttonname = buttonname.data.decode("utf-8")
		harga = db.execute("SELECT harga FROM trojangfw WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		domain = db.execute("SELECT domain FROM trojangfw WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		lim = db.execute("SELECT limcounted FROM trojangfw WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		cont = db.execute("SELECT counted FROM trojangfw WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
		z = requests.get(f"http://ip-api.com/json/{domain}?fields=country,region,city,timezone,isp").json()
		print(domain); print(harga); print(cont); print(lim)
		msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** Informasi Server **
**━━━━━━━━━━━━━━━━━━━**
**🔰 Server Name:** `{buttonname}`
**🔰 ISP:** `{z["isp"]}`
**🔰 Country:** `{z["country"]}`
**🔰 Domain:** `{domain}`
**🔰 Harga:** `{harga}`
**🔰 Total Akun Dibuat:** `{cont}/{lim}`
**━━━━━━━━━━━━━━━━━━━**
** Pilih Ya Untuk Lanjut...!! **
**━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=[
[Button.inline(" Ya ","y"),Button.inline(" Tidak ","n")],
[Button.inline(" 🔙 Back To Menu ","menu")]])
		async with bot.conversation(event.chat_id) as con:
			con = con.wait_event(events.CallbackQuery)
			con = await con
		if con.data.decode("ascii") != "y" and con.data.decode("ascii") != "menu":
			await event.respond("**Dibatalkan.**")
		elif con.data.decode("ascii") == "y":
			async with bot.conversation(event.chat_id) as user:
					await event.edit("**Username: **")
					user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
					user = await user
					user = user.message.message
					
			async with bot.conversation(event.chat_id) as exp:
				await event.respond("**Choose Expiry day**",
buttons=[
[Button.inline("30 Day","30")]])
				exp = exp.wait_event(events.CallbackQuery)
				exp = await exp
				exp = exp.data.decode("ascii")
			if lim == cont:
				await event.respond("**Server Full**")
			elif int(val["saldo"]) < harga:
				await event.respond("**Saldo Anda Tidak cukup**")
			else:
				if exp == "30":
					min = harga
				param = f"/trojan-create?user={user}&exp={exp}"
				r = requests.get("http://"+domain+":6969"+param)
				if r.text != "error":
					try:
						db.execute("UPDATE user SET saldo = ? WHERE member = ?",(int(val["saldo"])-int(min),sender.id,))
						count = db.execute("SELECT counted FROM trojangfw WHERE buttonname = (?)",(buttonname,)).fetchone()[0]
						db.execute("UPDATE trojangfw SET counted = (?) WHERE domain = (?)",
						(int(count)+int(1),domain,))
						db.commit()
					except:
						pass
					print(r.text)
					x = r.text
					today = DT.date.today()
					later = today + DT.timedelta(days=int(exp))
					print(x)
					domain = re.search("@(.*?):",x).group(1)
					port = re.search(domain+":(.*)",x).group(1)
					uuid = re.search("trojan://(.*?)@",x).group(1)
					try:
						remarks = re.search("#(.*)",x).group(1)
					except:
						remarks = uuid
					msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**  Trojan-GFW ACCOUNT **
**━━━━━━━━━━━━━━━━━━━**
**» Remarks:** `{uuid}`
**» Domain:** `{domain}`
**» Port TLS:** `443`
**» UUID:** `{uuid}`
**━━━━━━━━━━━━━━━━━━━**
**» TROJAN-GFW Url:**
  `{x.replace(" ","").strip()}`
**━━━━━━━━━━━━━━━━━━━**
**📆 Expired Until:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
					await event.respond(msg)
					
					dat = {
				"email":val["email"],
                                "protocol":"Trojan-GFW",
                                "server":domain,
                                "exp":str(later)}
					await notifs(dat, event)
				else:
					await event.respond("""
_**ERROR**_

**PROBABLY :-** `Username Already Exist`, `Server Error`
""")
		

	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT * FROM admin").fetchall()
	a = [v[0] for v in x]
	data = event.data.decode("ascii").split("-")[0]
	if val == "false":
		if sender.id not in a:
			await event.answer("Akses Ditolak")
		else:
			val = {"saldo":"100000000"}
			await trojangfw_(event)
	else:
		await trojangfw_(event)

@bot.on(events.CallbackQuery(data=b'trgfwmenu'))
async def trojangfwmenu(event):
	sender = await event.get_sender()
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	ser = namasgfw()
	har = hargasgfw()
	serv = []
	for x, y in zip(ser, har):
		print(x, y)
		serv.append(f"**📡 {x}  ** `Rp.{y}`\n")
	if val == "false":
		if sender.id in a:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** Trojan-GFW Account Menu **
**━━━━━━━━━━━━━━━━━━━**
**         💶  Price List  💶** 
** **
{"".join(serv)}


**━━━━━━━━━━━━━━━━━━━**
"""
			await event.edit(msg, buttons=[
[Button.inline(" Created Trojan-GFW ","create-trojangfw"),
Button.inline(" Created Trial Trojan-GFW ","trojangfw-trial")],
[Button.inline(" Renew Trojan-GFW Account ","rentrgfwo")],
[Button.inline("🔙 Back To Menu",f"menu")]])
		else:
			await event.answer("Akses Ditolak ❌")
	else:
		msg = f"""
**━━━━━━━━━━━━━━━━━━━**
** Trojan-GFW Account Menu **
**━━━━━━━━━━━━━━━━━━━**
**         💶  Price List  💶** 
** **
{"".join(serv)}


**━━━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg, buttons=[
[Button.inline(" Created Trojan-GFW ","create-trojangfw"),
Button.inline(" Created Trial Trojan-GFW ","trojangfw-trial")],
[Button.inline(" Renew Trojan-GFW Account ","rentrgfwo")],
[Button.inline("🔙 Back To Menu",f"menu")]])
