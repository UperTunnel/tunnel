from agin import *

@bot.on(events.CallbackQuery(data=b'menu'))
@bot.on(events.NewMessage(pattern="(?: /menu|.menu)$"))
async def menu(event):
	image_file = 'agin/img/image.jpg'
	result = await bot.upload_file(image_file)
	image = InputMediaUploadedPhoto(result)
	sender = await event.get_sender()
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	member = members()
	if sender.id in a:
		msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**⟨ ADMIN PANEL MENU ⟩**
**━━━━━━━━━━━━━━━━━━━━━━━**
**👥Total Member/Reseller:** `{member}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**🤖 Bot Uptime:** `{get_uptime()}`
"""
		z = await event.edit(msg,buttons=[
[Button.inline(" Panel Create Account ","submenu1"),
Button.inline(" Edit Quota Account","quotaq")],
[Button.inline(" Register Member ","register"),
Button.inline(" Delete Member ","delmem")],
[Button.inline(" Add Server ","svmenu"),
Button.inline(" Del Server ","delserver")],
[Button.inline(" Add Saldo To Member ","addsaldo"),
Button.inline(" Min Saldo To Member ","min")]])
		if not z:
			await event.respond(msg,buttons=[
[Button.inline(" Panel Create Account ","submenu1"),
Button.inline(" Edit Quota Account","quotaq")],
[Button.inline(" Register Member ","register"),
Button.inline(" Delete Member ","delmem")],
[Button.inline(" Add Server ","svmenu"),
Button.inline(" Del Server ","delserver")],
[Button.inline(" Add Saldo To Member ","addsaldo"),
Button.inline(" Min Saldo To Member ","min")]])
	else:
		val = valid(sender.id)
		if val == "false":
			try:
				await event.answer("**Akses ditolak ❌**")
			except:
				await event.respond("**Akses Ditolak ❌**")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
Halo Tuan {sender.first_name}
Selamat Datang Di Layanan VPN premium
Silahkan pilih menu dibawah.

Note:
- Saldo harus sesuai harga 30 Day untuk bisa bikin akun dengan harga 7 Day

info:
• Server Support Hospot/STB
• Max 1 STB atau khusus HP Max 2
Note:
- Wajib test **TRIAL** dahulu sebelum topup/membeli
- Untuk Cek Saldo ke Info Status 
**━━━━━━━━━━━━━━━━━━━━━━━**
Bot Uptime : `{get_uptime()}`
"""
			x = await event.edit(msg, file=image, buttons=[
[Button.inline(" SSH OVPN MANAGER ","ssh-menu")],
[Button.inline(" VMESS MANAGER ","vmess-menu"),
Button.inline(" VLESS MANAGER ","vless-menu")],
[Button.inline(" TROJAN MANAGER ","trwsmenu"),
Button.inline(" SHDWSK MANAGER ","shadowsocks")],
[Button.inline(" 👤INFO STATUS👤 ","info")]]) 
			if not x:
				await event.respond(msg, file=image, buttons=[
[Button.inline(" SSH OVPN MANAGER ","ssh-menu")],
[Button.inline(" VMESS MANAGER ","vmess-menu"),
Button.inline(" VLESS MANAGER ","vless-menu")],
[Button.inline(" TROJAN MANAGER ","trwsmenu"),
Button.inline(" SHDWSK MANAGER ","shadowsocks")],
[Button.inline(" 👤INFO STATUS👤 ","info")]]) 
